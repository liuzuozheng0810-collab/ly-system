
// data.ts - 陆压系统移动端核心数据库 (Read-Only Source)

export const searchDatabase = [
  {
    category: "通用叫法",
    items: [
      { title: "跻子/机子", subtitle: "专业名：凸台", fields: [{ label: "解释", value: "增加接触面积的平台，用于定位或承力。" }] },
      { title: "骨位", subtitle: "专业名：加强筋", fields: [{ label: "解释", value: "增加强度，防止变形，通常在壁厚较薄处设置。" }] },
      { title: "止口", subtitle: "专业名：定位台", fields: [{ label: "解释", value: "零件对齐用的台阶位。" }] }
    ]
  },
  {
    category: "缺陷参考",
    items: [
      { 
        title: "气孔", 
        subtitle: "代码：CA01", 
        fields: [
          { label: "特征", value: "光滑孔眼，通常呈圆形或梨形，表面洁净。" }, 
          { label: "原因", value: "型砂透气差、水分过高或浇注速度过快导致。" }
        ] 
      },
      { 
        title: "缩孔", 
        subtitle: "代码：CA02", 
        fields: [
          { label: "特征", value: "形状不规则，表面粗糙，通常发生在热节处。" }, 
          { label: "原因", value: "补缩不足或浇注温度过高。" }
        ] 
      }
    ]
  }
];

export const inspectionTemplates = [
  {
    category: "发货确认",
    items: ["产品外观确认", "产品标识检查", "涂漆检查", "唛头确认", "包装牢固度"]
  },
  {
    category: "CMTR确认",
    items: ["格式/盖章", "订单号校验", "材质名校验", "热处理记录校验", "炉号追溯性"]
  }
];

export const calcData = {
  materialDensity: {
    "HT200": 7.2,
    "HT250": 7.3,
    "QT450": 7.1,
    "ZG230-450": 7.8,
    "SS304": 7.93,
    "SS316": 7.98,
    "AL6061": 2.7
  },
  // Simplified DCT (Metric) Matrix for logic testing
  dctgMatrix: [
    { minSize: 0, maxSize: 10, grades: { DCTG5: 0.36, DCTG6: 0.52, DCTG7: 0.74, DCTG8: 1.0 } },
    { minSize: 10, maxSize: 16, grades: { DCTG5: 0.38, DCTG6: 0.54, DCTG7: 0.78, DCTG8: 1.1 } },
    { minSize: 16, maxSize: 25, grades: { DCTG5: 0.42, DCTG6: 0.58, DCTG7: 0.82, DCTG8: 1.2 } },
    { minSize: 25, maxSize: 40, grades: { DCTG5: 0.46, DCTG6: 0.64, DCTG7: 0.90, DCTG8: 1.3 } }
  ]
};

export const quickNoteConfig = {
  categories: ["质量异常", "现场记录", "会议纪要", "临时待办"],
  defaultAction: "语音转文字"
};
