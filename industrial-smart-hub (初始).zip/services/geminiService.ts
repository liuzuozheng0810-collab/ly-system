
import { GoogleGenAI } from "@google/genai";

// Industrial analysis is a complex task involving engineering reasoning and drawing interpretation.
// We use gemini-3-pro-preview for complex STEM/reasoning tasks.
export const analyzeIndustrialImage = async (base64Image: string, prompt: string) => {
  // Always use the named parameter and process.env.API_KEY directly as per guidelines.
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const imagePart = {
    inlineData: {
      mimeType: 'image/jpeg', // Standard MIME type for image data.
      data: base64Image, // base64 encoded string from file upload.
    },
  };
  
  // Use gemini-3-pro-preview for complex industrial reasoning.
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: { parts: [imagePart, { text: prompt }] },
    config: {
      systemInstruction: "You are a senior industrial engineer specializing in drawing analysis and quality control. Provide precise, technical, and actionable insights."
    }
  });

  // Access the text property directly (not as a method).
  return response.text;
};

// General chat uses the flash model for basic Q&A and faster response times.
export const chatWithAI = async (message: string) => {
    // Re-initialize client to ensure the latest API key is used.
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: message
    });
    
    // Access the text property directly.
    return response.text;
};